/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package secuenciasmaximales;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
/**
 *
 * @author alulab
 */
public class SecuenciasMaximales {
    private ArrayList<Documento> alstDocumento;
    private HashMap<String,Integer> diccionario;
    private ArrayList<String> alstPalabra;
    private int contDocumentos;
    private int contPalabras;
    /**
     * @param args the command line arguments
     */
    SecuenciasMaximales(){
        this.alstDocumento = new ArrayList<Documento>();
        this.diccionario = new HashMap<String,Integer>();
        this.alstPalabra = new ArrayList<String>();
        this.contDocumentos = 0;
        this.contPalabras = 0;
    }

    public void insertarPalabra(int idDoc, String word){
        System.out.println("Se trata de insertar " + word);
        if (diccionario.containsKey(word)){
            //Se debe agregar una referencia al documento predecesor
            int idxWord = diccionario.get(word);
             System.out.println(word + " ya existia en el diccionario con id = " + idxWord);
            alstDocumento.get(idDoc).insertarNodoPalabra(idxWord);
        }
        else {
            //Agregamos al HashMap
            diccionario.put(word, contPalabras);
            int idxWord = contPalabras;
            System.out.println(word + " no existe en el diccionario, se inserta con id = " + idxWord);
            alstPalabra.add(word);
            alstDocumento.get(idDoc).insertarNodoPalabra(idxWord);
            contPalabras++;
        }
    }

    public void agregarDocumento(){
        /* Insertamos un nuevo documento y aumentamos el contador */
        alstDocumento.add(new Documento(contDocumentos++));
    }

    public int getIdDocActual(){
        return contDocumentos - 1;
    }

    public void leerDocumento(){
        Scanner in = new Scanner(System.in);
        String word;
        this.agregarDocumento();
        int docActual = this.getIdDocActual();
        int n = in.nextInt();
        in.nextLine();
        for (int i= 0; i < n; ++i){
            word = in.nextLine();
            this.insertarPalabra(docActual, word);
        }
       this.alstDocumento.get(docActual).cerrarEnlaces();
    } 

    public void recorrerDocActual(){
        int docActual = this.getIdDocActual();
        for (int i=0; i < alstPalabra.size(); ++i){
            System.out.println("Palabra = " + alstPalabra.get(i) + "\tidPalabra = " + i);
        }
        this.alstDocumento.get(docActual).recorrerDocumento();
    }

    public static void main(String[] args) {
        // TODO code application logic here
        SecuenciasMaximales sm = new SecuenciasMaximales();
        sm.leerDocumento();
        sm.recorrerDocActual();
    }

}
